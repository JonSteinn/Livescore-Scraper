import json
import random
import sys
import threading
import time
from urllib import request

england1 = [
    {
        "draws": 4,
        "goal_difference": 79,
        "goals_received": 27,
        "goals_scored": 106,
        "losses": 2,
        "played": 38,
        "points": 100,
        "team": "Manchester City",
        "wins": 32
    },
    {
        "draws": 6,
        "goal_difference": 40,
        "goals_received": 28,
        "goals_scored": 68,
        "losses": 7,
        "played": 38,
        "points": 81,
        "team": "Manchester United",
        "wins": 25
    },
    {
        "draws": 8,
        "goal_difference": 38,
        "goals_received": 36,
        "goals_scored": 74,
        "losses": 7,
        "played": 38,
        "points": 77,
        "team": "Tottenham Hotspur",
        "wins": 23
    },
    {
        "draws": 12,
        "goal_difference": 46,
        "goals_received": 38,
        "goals_scored": 84,
        "losses": 5,
        "played": 38,
        "points": 75,
        "team": "Liverpool",
        "wins": 21
    },
    {
        "draws": 7,
        "goal_difference": 24,
        "goals_received": 38,
        "goals_scored": 62,
        "losses": 10,
        "played": 38,
        "points": 70,
        "team": "Chelsea",
        "wins": 21
    },
    {
        "draws": 6,
        "goal_difference": 23,
        "goals_received": 51,
        "goals_scored": 74,
        "losses": 13,
        "played": 38,
        "points": 63,
        "team": "Arsenal",
        "wins": 19
    },
    {
        "draws": 12,
        "goal_difference": -3,
        "goals_received": 39,
        "goals_scored": 36,
        "losses": 12,
        "played": 38,
        "points": 54,
        "team": "Burnley",
        "wins": 14
    },
    {
        "draws": 10,
        "goal_difference": -14,
        "goals_received": 58,
        "goals_scored": 44,
        "losses": 15,
        "played": 38,
        "points": 49,
        "team": "Everton",
        "wins": 13
    },
    {
        "draws": 11,
        "goal_difference": -4,
        "goals_received": 60,
        "goals_scored": 56,
        "losses": 15,
        "played": 38,
        "points": 47,
        "team": "Leicester City",
        "wins": 12
    },
    {
        "draws": 8,
        "goal_difference": -8,
        "goals_received": 47,
        "goals_scored": 39,
        "losses": 18,
        "played": 38,
        "points": 44,
        "team": "Newcastle United",
        "wins": 12
    },
    {
        "draws": 11,
        "goal_difference": -10,
        "goals_received": 55,
        "goals_scored": 45,
        "losses": 16,
        "played": 38,
        "points": 44,
        "team": "Crystal Palace",
        "wins": 11
    },
    {
        "draws": 11,
        "goal_difference": -16,
        "goals_received": 61,
        "goals_scored": 45,
        "losses": 16,
        "played": 38,
        "points": 44,
        "team": "AFC Bournemouth",
        "wins": 11
    },
    {
        "draws": 12,
        "goal_difference": -20,
        "goals_received": 68,
        "goals_scored": 48,
        "losses": 16,
        "played": 38,
        "points": 42,
        "team": "West Ham United",
        "wins": 10
    },
    {
        "draws": 8,
        "goal_difference": -20,
        "goals_received": 64,
        "goals_scored": 44,
        "losses": 19,
        "played": 38,
        "points": 41,
        "team": "Watford",
        "wins": 11
    },
    {
        "draws": 13,
        "goal_difference": -20,
        "goals_received": 54,
        "goals_scored": 34,
        "losses": 16,
        "played": 38,
        "points": 40,
        "team": "Brighton &amp; Hove Albion",
        "wins": 9
    },
    {
        "draws": 10,
        "goal_difference": -30,
        "goals_received": 58,
        "goals_scored": 28,
        "losses": 19,
        "played": 38,
        "points": 37,
        "team": "Huddersfield Town",
        "wins": 9
    },
    {
        "draws": 15,
        "goal_difference": -19,
        "goals_received": 56,
        "goals_scored": 37,
        "losses": 16,
        "played": 38,
        "points": 36,
        "team": "Southampton",
        "wins": 7
    },
    {
        "draws": 9,
        "goal_difference": -28,
        "goals_received": 56,
        "goals_scored": 28,
        "losses": 21,
        "played": 38,
        "points": 33,
        "team": "Swansea City",
        "wins": 8
    },
    {
        "draws": 12,
        "goal_difference": -33,
        "goals_received": 68,
        "goals_scored": 35,
        "losses": 19,
        "played": 38,
        "points": 33,
        "team": "Stoke City",
        "wins": 7
    },
    {
        "draws": 13,
        "goal_difference": -25,
        "goals_received": 56,
        "goals_scored": 31,
        "losses": 19,
        "played": 38,
        "points": 31,
        "team": "West Bromwich Albion",
        "wins": 6
    }
]

england2 = [
    {
        "draws": 9,
        "goal_difference": 43,
        "goals_received": 39,
        "goals_scored": 82,
        "losses": 7,
        "played": 46,
        "points": 99,
        "team": "Wolverhampton Wanderers",
        "wins": 30
    },
    {
        "draws": 9,
        "goal_difference": 30,
        "goals_received": 39,
        "goals_scored": 69,
        "losses": 10,
        "played": 46,
        "points": 90,
        "team": "Cardiff City",
        "wins": 27
    },
    {
        "draws": 13,
        "goal_difference": 33,
        "goals_received": 46,
        "goals_scored": 79,
        "losses": 8,
        "played": 46,
        "points": 88,
        "team": "Fulham",
        "wins": 25
    },
    {
        "draws": 11,
        "goal_difference": 30,
        "goals_received": 42,
        "goals_scored": 72,
        "losses": 11,
        "played": 46,
        "points": 83,
        "team": "Aston Villa",
        "wins": 24
    },
    {
        "draws": 10,
        "goal_difference": 22,
        "goals_received": 45,
        "goals_scored": 67,
        "losses": 14,
        "played": 46,
        "points": 76,
        "team": "Middlesbrough",
        "wins": 22
    },
    {
        "draws": 15,
        "goal_difference": 22,
        "goals_received": 48,
        "goals_scored": 70,
        "losses": 11,
        "played": 46,
        "points": 75,
        "team": "Derby County",
        "wins": 20
    },
    {
        "draws": 16,
        "goal_difference": 11,
        "goals_received": 46,
        "goals_scored": 57,
        "losses": 11,
        "played": 46,
        "points": 73,
        "team": "Preston North End",
        "wins": 19
    },
    {
        "draws": 15,
        "goal_difference": 11,
        "goals_received": 45,
        "goals_scored": 56,
        "losses": 12,
        "played": 46,
        "points": 72,
        "team": "Millwall",
        "wins": 19
    },
    {
        "draws": 15,
        "goal_difference": 10,
        "goals_received": 52,
        "goals_scored": 62,
        "losses": 13,
        "played": 46,
        "points": 69,
        "team": "Brentford",
        "wins": 18
    },
    {
        "draws": 9,
        "goal_difference": 7,
        "goals_received": 55,
        "goals_scored": 62,
        "losses": 17,
        "played": 46,
        "points": 69,
        "team": "Sheffield United",
        "wins": 20
    },
    {
        "draws": 16,
        "goal_difference": 9,
        "goals_received": 58,
        "goals_scored": 67,
        "losses": 13,
        "played": 46,
        "points": 67,
        "team": "Bristol City",
        "wins": 17
    },
    {
        "draws": 9,
        "goal_difference": -3,
        "goals_received": 60,
        "goals_scored": 57,
        "losses": 20,
        "played": 46,
        "points": 60,
        "team": "Ipswich Town",
        "wins": 17
    },
    {
        "draws": 9,
        "goal_difference": -5,
        "goals_received": 64,
        "goals_scored": 59,
        "losses": 20,
        "played": 46,
        "points": 60,
        "team": "Leeds United",
        "wins": 17
    },
    {
        "draws": 15,
        "goal_difference": -11,
        "goals_received": 60,
        "goals_scored": 49,
        "losses": 16,
        "played": 46,
        "points": 60,
        "team": "Norwich City",
        "wins": 15
    },
    {
        "draws": 15,
        "goal_difference": -1,
        "goals_received": 60,
        "goals_scored": 59,
        "losses": 17,
        "played": 46,
        "points": 57,
        "team": "Sheffield Wednesday",
        "wins": 14
    },
    {
        "draws": 11,
        "goal_difference": -12,
        "goals_received": 70,
        "goals_scored": 58,
        "losses": 20,
        "played": 46,
        "points": 56,
        "team": "Queens Park Rangers",
        "wins": 15
    },
    {
        "draws": 8,
        "goal_difference": -14,
        "goals_received": 65,
        "goals_scored": 51,
        "losses": 23,
        "played": 46,
        "points": 53,
        "team": "Nottingham Forest",
        "wins": 15
    },
    {
        "draws": 16,
        "goal_difference": 0,
        "goals_received": 70,
        "goals_scored": 70,
        "losses": 19,
        "played": 46,
        "points": 49,
        "team": "Hull City",
        "wins": 11
    },
    {
        "draws": 7,
        "goal_difference": -30,
        "goals_received": 68,
        "goals_scored": 38,
        "losses": 26,
        "played": 46,
        "points": 46,
        "team": "Birmingham City",
        "wins": 13
    },
    {
        "draws": 14,
        "goal_difference": -22,
        "goals_received": 70,
        "goals_scored": 48,
        "losses": 22,
        "played": 46,
        "points": 44,
        "team": "Reading",
        "wins": 10
    },
    {
        "draws": 13,
        "goal_difference": -35,
        "goals_received": 74,
        "goals_scored": 39,
        "losses": 23,
        "played": 46,
        "points": 43,
        "team": "Bolton Wanderers",
        "wins": 10
    },
    {
        "draws": 14,
        "goal_difference": -24,
        "goals_received": 72,
        "goals_scored": 48,
        "losses": 23,
        "played": 46,
        "points": 41,
        "team": "Barnsley",
        "wins": 9
    },
    {
        "draws": 11,
        "goal_difference": -43,
        "goals_received": 81,
        "goals_scored": 38,
        "losses": 25,
        "played": 46,
        "points": 41,
        "team": "Burton Albion",
        "wins": 10
    },
    {
        "draws": 16,
        "goal_difference": -28,
        "goals_received": 80,
        "goals_scored": 52,
        "losses": 23,
        "played": 46,
        "points": 37,
        "team": "Sunderland",
        "wins": 7
    }
]

england3 = [
    {
        "draws": 11,
        "goal_difference": 60,
        "goals_received": 29,
        "goals_scored": 89,
        "losses": 6,
        "played": 46,
        "points": 98,
        "team": "Wigan Athletic",
        "wins": 29
    },
    {
        "draws": 12,
        "goal_difference": 42,
        "goals_received": 40,
        "goals_scored": 82,
        "losses": 6,
        "played": 46,
        "points": 96,
        "team": "Blackburn Rovers",
        "wins": 28
    },
    {
        "draws": 12,
        "goal_difference": 21,
        "goals_received": 39,
        "goals_scored": 60,
        "losses": 9,
        "played": 46,
        "points": 87,
        "team": "Shrewsbury Town",
        "wins": 25
    },
    {
        "draws": 7,
        "goal_difference": 20,
        "goals_received": 53,
        "goals_scored": 73,
        "losses": 15,
        "played": 46,
        "points": 79,
        "team": "Rotherham United",
        "wins": 24
    },
    {
        "draws": 17,
        "goal_difference": 15,
        "goals_received": 50,
        "goals_scored": 65,
        "losses": 10,
        "played": 46,
        "points": 74,
        "team": "Scunthorpe United",
        "wins": 19
    },
    {
        "draws": 11,
        "goal_difference": 7,
        "goals_received": 51,
        "goals_scored": 58,
        "losses": 15,
        "played": 46,
        "points": 71,
        "team": "Charlton Athletic",
        "wins": 20
    },
    {
        "draws": 11,
        "goal_difference": -1,
        "goals_received": 59,
        "goals_scored": 58,
        "losses": 16,
        "played": 46,
        "points": 68,
        "team": "Plymouth Argyle",
        "wins": 19
    },
    {
        "draws": 6,
        "goal_difference": 1,
        "goals_received": 56,
        "goals_scored": 57,
        "losses": 20,
        "played": 46,
        "points": 66,
        "team": "Portsmouth",
        "wins": 20
    },
    {
        "draws": 13,
        "goal_difference": 8,
        "goals_received": 60,
        "goals_scored": 68,
        "losses": 16,
        "played": 46,
        "points": 64,
        "team": "Peterborough United",
        "wins": 17
    },
    {
        "draws": 12,
        "goal_difference": -4,
        "goals_received": 62,
        "goals_scored": 58,
        "losses": 17,
        "played": 46,
        "points": 63,
        "team": "Southend United",
        "wins": 17
    },
    {
        "draws": 9,
        "goal_difference": -10,
        "goals_received": 67,
        "goals_scored": 57,
        "losses": 19,
        "played": 46,
        "points": 63,
        "team": "Bradford City",
        "wins": 18
    },
    {
        "draws": 15,
        "goal_difference": 5,
        "goals_received": 55,
        "goals_scored": 60,
        "losses": 16,
        "played": 46,
        "points": 60,
        "team": "Blackpool",
        "wins": 15
    },
    {
        "draws": 11,
        "goal_difference": -6,
        "goals_received": 66,
        "goals_scored": 60,
        "losses": 19,
        "played": 46,
        "points": 59,
        "team": "Bristol Rovers",
        "wins": 16
    },
    {
        "draws": 9,
        "goal_difference": -9,
        "goals_received": 68,
        "goals_scored": 59,
        "losses": 21,
        "played": 46,
        "points": 57,
        "team": "Fleetwood Town",
        "wins": 16
    },
    {
        "draws": 17,
        "goal_difference": 0,
        "goals_received": 52,
        "goals_scored": 52,
        "losses": 16,
        "played": 46,
        "points": 56,
        "team": "Doncaster Rovers",
        "wins": 13
    },
    {
        "draws": 11,
        "goal_difference": -5,
        "goals_received": 66,
        "goals_scored": 61,
        "losses": 20,
        "played": 46,
        "points": 56,
        "team": "Oxford United",
        "wins": 15
    },
    {
        "draws": 17,
        "goal_difference": -5,
        "goals_received": 55,
        "goals_scored": 50,
        "losses": 16,
        "played": 46,
        "points": 56,
        "team": "Gillingham",
        "wins": 13
    },
    {
        "draws": 14,
        "goal_difference": -11,
        "goals_received": 58,
        "goals_scored": 47,
        "losses": 19,
        "played": 46,
        "points": 53,
        "team": "AFC Wimbledon",
        "wins": 13
    },
    {
        "draws": 13,
        "goal_difference": -13,
        "goals_received": 66,
        "goals_scored": 53,
        "losses": 20,
        "played": 46,
        "points": 52,
        "team": "Walsall",
        "wins": 13
    },
    {
        "draws": 18,
        "goal_difference": -8,
        "goals_received": 57,
        "goals_scored": 49,
        "losses": 17,
        "played": 46,
        "points": 51,
        "team": "Rochdale",
        "wins": 11
    },
    {
        "draws": 17,
        "goal_difference": -17,
        "goals_received": 75,
        "goals_scored": 58,
        "losses": 18,
        "played": 46,
        "points": 50,
        "team": "Oldham Athletic",
        "wins": 11
    },
    {
        "draws": 11,
        "goal_difference": -34,
        "goals_received": 77,
        "goals_scored": 43,
        "losses": 23,
        "played": 46,
        "points": 47,
        "team": "Northampton Town",
        "wins": 12
    },
    {
        "draws": 12,
        "goal_difference": -26,
        "goals_received": 69,
        "goals_scored": 43,
        "losses": 23,
        "played": 46,
        "points": 45,
        "team": "Milton Keynes Dons",
        "wins": 11
    },
    {
        "draws": 12,
        "goal_difference": -30,
        "goals_received": 71,
        "goals_scored": 41,
        "losses": 26,
        "played": 46,
        "points": 36,
        "team": "Bury",
        "wins": 8
    }
]

england4 = [
    {
        "draws": 6,
        "goal_difference": 30,
        "goals_received": 46,
        "goals_scored": 76,
        "losses": 11,
        "played": 46,
        "points": 93,
        "team": "Accrington Stanley",
        "wins": 29
    },
    {
        "draws": 13,
        "goal_difference": 48,
        "goals_received": 46,
        "goals_scored": 94,
        "losses": 8,
        "played": 46,
        "points": 88,
        "team": "Luton Town",
        "wins": 25
    },
    {
        "draws": 12,
        "goal_difference": 19,
        "goals_received": 60,
        "goals_scored": 79,
        "losses": 10,
        "played": 46,
        "points": 84,
        "team": "Wycombe Wanderers",
        "wins": 24
    },
    {
        "draws": 8,
        "goal_difference": 10,
        "goals_received": 54,
        "goals_scored": 64,
        "losses": 14,
        "played": 46,
        "points": 80,
        "team": "Exeter City",
        "wins": 24
    },
    {
        "draws": 14,
        "goal_difference": 23,
        "goals_received": 48,
        "goals_scored": 71,
        "losses": 11,
        "played": 46,
        "points": 77,
        "team": "Notts County",
        "wins": 21
    },
    {
        "draws": 9,
        "goal_difference": 17,
        "goals_received": 47,
        "goals_scored": 64,
        "losses": 15,
        "played": 46,
        "points": 75,
        "team": "Coventry City",
        "wins": 22
    },
    {
        "draws": 15,
        "goal_difference": 16,
        "goals_received": 48,
        "goals_scored": 64,
        "losses": 11,
        "played": 46,
        "points": 75,
        "team": "Lincoln City",
        "wins": 20
    },
    {
        "draws": 18,
        "goal_difference": 15,
        "goals_received": 52,
        "goals_scored": 67,
        "losses": 10,
        "played": 46,
        "points": 72,
        "team": "Mansfield Town",
        "wins": 18
    },
    {
        "draws": 8,
        "goal_difference": 2,
        "goals_received": 65,
        "goals_scored": 67,
        "losses": 18,
        "played": 46,
        "points": 68,
        "team": "Swindon Town",
        "wins": 20
    },
    {
        "draws": 16,
        "goal_difference": 8,
        "goals_received": 54,
        "goals_scored": 62,
        "losses": 13,
        "played": 46,
        "points": 67,
        "team": "Carlisle United",
        "wins": 17
    },
    {
        "draws": 16,
        "goal_difference": -2,
        "goals_received": 58,
        "goals_scored": 56,
        "losses": 14,
        "played": 46,
        "points": 64,
        "team": "Newport County",
        "wins": 16
    },
    {
        "draws": 13,
        "goal_difference": -4,
        "goals_received": 60,
        "goals_scored": 56,
        "losses": 16,
        "played": 46,
        "points": 64,
        "team": "Cambridge United",
        "wins": 17
    },
    {
        "draws": 14,
        "goal_difference": 1,
        "goals_received": 52,
        "goals_scored": 53,
        "losses": 16,
        "played": 46,
        "points": 62,
        "team": "Colchester United",
        "wins": 16
    },
    {
        "draws": 11,
        "goal_difference": -8,
        "goals_received": 66,
        "goals_scored": 58,
        "losses": 19,
        "played": 46,
        "points": 59,
        "team": "Crawley Town",
        "wins": 16
    },
    {
        "draws": 5,
        "goal_difference": -13,
        "goals_received": 75,
        "goals_scored": 62,
        "losses": 24,
        "played": 46,
        "points": 56,
        "team": "Crewe Alexandra",
        "wins": 17
    },
    {
        "draws": 13,
        "goal_difference": -5,
        "goals_received": 65,
        "goals_scored": 60,
        "losses": 19,
        "played": 46,
        "points": 55,
        "team": "Stevenage",
        "wins": 14
    },
    {
        "draws": 12,
        "goal_difference": -6,
        "goals_received": 73,
        "goals_scored": 67,
        "losses": 21,
        "played": 46,
        "points": 51,
        "team": "Cheltenham Town",
        "wins": 13
    },
    {
        "draws": 12,
        "goal_difference": -24,
        "goals_received": 66,
        "goals_scored": 42,
        "losses": 21,
        "played": 46,
        "points": 51,
        "team": "Grimsby Town",
        "wins": 13
    },
    {
        "draws": 12,
        "goal_difference": -16,
        "goals_received": 75,
        "goals_scored": 59,
        "losses": 22,
        "played": 46,
        "points": 48,
        "team": "Yeovil Town",
        "wins": 12
    },
    {
        "draws": 14,
        "goal_difference": -18,
        "goals_received": 67,
        "goals_scored": 49,
        "losses": 21,
        "played": 46,
        "points": 47,
        "team": "Port Vale",
        "wins": 11
    },
    {
        "draws": 8,
        "goal_difference": -23,
        "goals_received": 77,
        "goals_scored": 54,
        "losses": 25,
        "played": 46,
        "points": 47,
        "team": "Forest Green Rovers",
        "wins": 13
    },
    {
        "draws": 19,
        "goal_difference": -15,
        "goals_received": 56,
        "goals_scored": 41,
        "losses": 18,
        "played": 46,
        "points": 46,
        "team": "Morecambe",
        "wins": 9
    },
    {
        "draws": 10,
        "goal_difference": -19,
        "goals_received": 65,
        "goals_scored": 46,
        "losses": 24,
        "played": 46,
        "points": 46,
        "team": "Barnet",
        "wins": 12
    },
    {
        "draws": 8,
        "goal_difference": -36,
        "goals_received": 83,
        "goals_scored": 47,
        "losses": 28,
        "played": 46,
        "points": 38,
        "team": "Chesterfield",
        "wins": 10
    }
]

italy1 = [
    {
        "draws": 5,
        "goal_difference": 62,
        "goals_received": 24,
        "goals_scored": 86,
        "losses": 3,
        "played": 38,
        "points": 95,
        "team": "Juventus",
        "wins": 30
    },
    {
        "draws": 7,
        "goal_difference": 48,
        "goals_received": 29,
        "goals_scored": 77,
        "losses": 3,
        "played": 38,
        "points": 91,
        "team": "SSC Napoli",
        "wins": 28
    },
    {
        "draws": 8,
        "goal_difference": 33,
        "goals_received": 28,
        "goals_scored": 61,
        "losses": 7,
        "played": 38,
        "points": 77,
        "team": "Roma",
        "wins": 23
    },
    {
        "draws": 12,
        "goal_difference": 36,
        "goals_received": 30,
        "goals_scored": 66,
        "losses": 6,
        "played": 38,
        "points": 72,
        "team": "Inter",
        "wins": 20
    },
    {
        "draws": 9,
        "goal_difference": 40,
        "goals_received": 49,
        "goals_scored": 89,
        "losses": 8,
        "played": 38,
        "points": 72,
        "team": "Lazio",
        "wins": 21
    },
    {
        "draws": 10,
        "goal_difference": 14,
        "goals_received": 42,
        "goals_scored": 56,
        "losses": 10,
        "played": 38,
        "points": 64,
        "team": "AC Milan",
        "wins": 18
    },
    {
        "draws": 12,
        "goal_difference": 18,
        "goals_received": 39,
        "goals_scored": 57,
        "losses": 10,
        "played": 38,
        "points": 60,
        "team": "Atalanta",
        "wins": 16
    },
    {
        "draws": 9,
        "goal_difference": 8,
        "goals_received": 46,
        "goals_scored": 54,
        "losses": 13,
        "played": 38,
        "points": 57,
        "team": "Fiorentina",
        "wins": 16
    },
    {
        "draws": 15,
        "goal_difference": 8,
        "goals_received": 46,
        "goals_scored": 54,
        "losses": 10,
        "played": 38,
        "points": 54,
        "team": "Torino",
        "wins": 13
    },
    {
        "draws": 6,
        "goal_difference": -4,
        "goals_received": 60,
        "goals_scored": 56,
        "losses": 16,
        "played": 38,
        "points": 54,
        "team": "Sampdoria",
        "wins": 16
    },
    {
        "draws": 10,
        "goal_difference": -30,
        "goals_received": 59,
        "goals_scored": 29,
        "losses": 17,
        "played": 38,
        "points": 43,
        "team": "Sassuolo",
        "wins": 11
    },
    {
        "draws": 8,
        "goal_difference": -10,
        "goals_received": 43,
        "goals_scored": 33,
        "losses": 19,
        "played": 38,
        "points": 41,
        "team": "Genoa",
        "wins": 11
    },
    {
        "draws": 10,
        "goal_difference": -23,
        "goals_received": 59,
        "goals_scored": 36,
        "losses": 18,
        "played": 38,
        "points": 40,
        "team": "ChievoVerona",
        "wins": 10
    },
    {
        "draws": 4,
        "goal_difference": -15,
        "goals_received": 63,
        "goals_scored": 48,
        "losses": 22,
        "played": 38,
        "points": 40,
        "team": "Udinese",
        "wins": 12
    },
    {
        "draws": 6,
        "goal_difference": -12,
        "goals_received": 52,
        "goals_scored": 40,
        "losses": 21,
        "played": 38,
        "points": 39,
        "team": "Bologna",
        "wins": 11
    },
    {
        "draws": 6,
        "goal_difference": -28,
        "goals_received": 61,
        "goals_scored": 33,
        "losses": 21,
        "played": 38,
        "points": 39,
        "team": "Cagliari",
        "wins": 11
    },
    {
        "draws": 14,
        "goal_difference": -20,
        "goals_received": 59,
        "goals_scored": 39,
        "losses": 16,
        "played": 38,
        "points": 38,
        "team": "SPAL 2013",
        "wins": 8
    },
    {
        "draws": 8,
        "goal_difference": -26,
        "goals_received": 66,
        "goals_scored": 40,
        "losses": 21,
        "played": 38,
        "points": 35,
        "team": "Crotone",
        "wins": 9
    },
    {
        "draws": 4,
        "goal_difference": -48,
        "goals_received": 78,
        "goals_scored": 30,
        "losses": 27,
        "played": 38,
        "points": 25,
        "team": "Hellas Verona",
        "wins": 7
    },
    {
        "draws": 3,
        "goal_difference": -51,
        "goals_received": 84,
        "goals_scored": 33,
        "losses": 29,
        "played": 38,
        "points": 21,
        "team": "Benevento",
        "wins": 6
    }
]

italy2 = [
    {
        "draws": 13,
        "goal_difference": 39,
        "goals_received": 49,
        "goals_scored": 88,
        "losses": 5,
        "played": 42,
        "points": 85,
        "team": "Empoli",
        "wins": 24
    },
    {
        "draws": 9,
        "goal_difference": 20,
        "goals_received": 37,
        "goals_scored": 57,
        "losses": 12,
        "played": 42,
        "points": 72,
        "team": "Parma Calcio 1913",
        "wins": 21
    },
    {
        "draws": 15,
        "goal_difference": 18,
        "goals_received": 47,
        "goals_scored": 65,
        "losses": 8,
        "played": 42,
        "points": 72,
        "team": "Frosinone",
        "wins": 19
    },
    {
        "draws": 17,
        "goal_difference": 20,
        "goals_received": 39,
        "goals_scored": 59,
        "losses": 7,
        "played": 42,
        "points": 71,
        "team": "Palermo",
        "wins": 18
    },
    {
        "draws": 16,
        "goal_difference": 14,
        "goals_received": 42,
        "goals_scored": 56,
        "losses": 9,
        "played": 42,
        "points": 67,
        "team": "Venezia",
        "wins": 17
    },
    {
        "draws": 12,
        "goal_difference": 13,
        "goals_received": 48,
        "goals_scored": 61,
        "losses": 12,
        "played": 42,
        "points": 66,
        "team": "Cittadella",
        "wins": 18
    },
    {
        "draws": 13,
        "goal_difference": 11,
        "goals_received": 48,
        "goals_scored": 59,
        "losses": 11,
        "played": 42,
        "points": 65,
        "team": "Bari",
        "wins": 18
    },
    {
        "draws": 12,
        "goal_difference": 9,
        "goals_received": 58,
        "goals_scored": 67,
        "losses": 14,
        "played": 42,
        "points": 60,
        "team": "Perugia",
        "wins": 16
    },
    {
        "draws": 10,
        "goal_difference": -2,
        "goals_received": 68,
        "goals_scored": 66,
        "losses": 16,
        "played": 42,
        "points": 58,
        "team": "Foggia",
        "wins": 16
    },
    {
        "draws": 14,
        "goal_difference": 1,
        "goals_received": 45,
        "goals_scored": 46,
        "losses": 15,
        "played": 42,
        "points": 53,
        "team": "Spezia",
        "wins": 13
    },
    {
        "draws": 16,
        "goal_difference": -14,
        "goals_received": 46,
        "goals_scored": 32,
        "losses": 14,
        "played": 42,
        "points": 52,
        "team": "Carpi",
        "wins": 12
    },
    {
        "draws": 18,
        "goal_difference": -7,
        "goals_received": 58,
        "goals_scored": 51,
        "losses": 13,
        "played": 42,
        "points": 51,
        "team": "Salernitana",
        "wins": 11
    },
    {
        "draws": 17,
        "goal_difference": -6,
        "goals_received": 61,
        "goals_scored": 55,
        "losses": 14,
        "played": 42,
        "points": 50,
        "team": "Cesena",
        "wins": 11
    },
    {
        "draws": 21,
        "goal_difference": 1,
        "goals_received": 47,
        "goals_scored": 48,
        "losses": 12,
        "played": 42,
        "points": 48,
        "team": "Cremonese",
        "wins": 9
    },
    {
        "draws": 15,
        "goal_difference": -11,
        "goals_received": 60,
        "goals_scored": 49,
        "losses": 16,
        "played": 42,
        "points": 48,
        "team": "Avellino",
        "wins": 11
    },
    {
        "draws": 15,
        "goal_difference": -11,
        "goals_received": 52,
        "goals_scored": 41,
        "losses": 16,
        "played": 42,
        "points": 48,
        "team": "Brescia",
        "wins": 11
    },
    {
        "draws": 15,
        "goal_difference": -14,
        "goals_received": 64,
        "goals_scored": 50,
        "losses": 16,
        "played": 42,
        "points": 48,
        "team": "Pescara",
        "wins": 11
    },
    {
        "draws": 13,
        "goal_difference": -20,
        "goals_received": 60,
        "goals_scored": 40,
        "losses": 18,
        "played": 42,
        "points": 46,
        "team": "Ascoli Picchio FC 1898",
        "wins": 11
    },
    {
        "draws": 14,
        "goal_difference": -13,
        "goals_received": 54,
        "goals_scored": 41,
        "losses": 18,
        "played": 42,
        "points": 44,
        "team": "Virtus Entella",
        "wins": 10
    },
    {
        "draws": 14,
        "goal_difference": -10,
        "goals_received": 52,
        "goals_scored": 42,
        "losses": 18,
        "played": 42,
        "points": 44,
        "team": "Novara",
        "wins": 10
    },
    {
        "draws": 13,
        "goal_difference": -23,
        "goals_received": 70,
        "goals_scored": 47,
        "losses": 20,
        "played": 42,
        "points": 40,
        "team": "Pro Vercelli",
        "wins": 9
    },
    {
        "draws": 16,
        "goal_difference": -15,
        "goals_received": 77,
        "goals_scored": 62,
        "losses": 19,
        "played": 42,
        "points": 37,
        "team": "Ternana",
        "wins": 7
    }
]

spain1 = [
    {
        "draws": 9,
        "goal_difference": 70,
        "goals_received": 29,
        "goals_scored": 99,
        "losses": 1,
        "played": 38,
        "points": 93,
        "team": "Barcelona",
        "wins": 28
    },
    {
        "draws": 10,
        "goal_difference": 36,
        "goals_received": 22,
        "goals_scored": 58,
        "losses": 5,
        "played": 38,
        "points": 79,
        "team": "Atletico Madrid",
        "wins": 23
    },
    {
        "draws": 10,
        "goal_difference": 50,
        "goals_received": 44,
        "goals_scored": 94,
        "losses": 6,
        "played": 38,
        "points": 76,
        "team": "Real Madrid",
        "wins": 22
    },
    {
        "draws": 7,
        "goal_difference": 27,
        "goals_received": 38,
        "goals_scored": 65,
        "losses": 9,
        "played": 38,
        "points": 73,
        "team": "Valencia",
        "wins": 22
    },
    {
        "draws": 7,
        "goal_difference": 7,
        "goals_received": 50,
        "goals_scored": 57,
        "losses": 13,
        "played": 38,
        "points": 61,
        "team": "Villarreal",
        "wins": 18
    },
    {
        "draws": 6,
        "goal_difference": -1,
        "goals_received": 61,
        "goals_scored": 60,
        "losses": 14,
        "played": 38,
        "points": 60,
        "team": "Real Betis",
        "wins": 18
    },
    {
        "draws": 7,
        "goal_difference": -9,
        "goals_received": 58,
        "goals_scored": 49,
        "losses": 14,
        "played": 38,
        "points": 58,
        "team": "Sevilla",
        "wins": 17
    },
    {
        "draws": 10,
        "goal_difference": 9,
        "goals_received": 33,
        "goals_scored": 42,
        "losses": 13,
        "played": 38,
        "points": 55,
        "team": "Getafe",
        "wins": 15
    },
    {
        "draws": 9,
        "goal_difference": -6,
        "goals_received": 50,
        "goals_scored": 44,
        "losses": 15,
        "played": 38,
        "points": 51,
        "team": "Eibar",
        "wins": 14
    },
    {
        "draws": 9,
        "goal_difference": -9,
        "goals_received": 59,
        "goals_scored": 50,
        "losses": 15,
        "played": 38,
        "points": 51,
        "team": "Girona",
        "wins": 14
    },
    {
        "draws": 13,
        "goal_difference": -6,
        "goals_received": 42,
        "goals_scored": 36,
        "losses": 13,
        "played": 38,
        "points": 49,
        "team": "Espanyol",
        "wins": 12
    },
    {
        "draws": 7,
        "goal_difference": 7,
        "goals_received": 59,
        "goals_scored": 66,
        "losses": 17,
        "played": 38,
        "points": 49,
        "team": "Real Sociedad",
        "wins": 14
    },
    {
        "draws": 10,
        "goal_difference": -1,
        "goals_received": 60,
        "goals_scored": 59,
        "losses": 15,
        "played": 38,
        "points": 49,
        "team": "Celta Vigo",
        "wins": 13
    },
    {
        "draws": 2,
        "goal_difference": -10,
        "goals_received": 50,
        "goals_scored": 40,
        "losses": 21,
        "played": 38,
        "points": 47,
        "team": "Alaves",
        "wins": 15
    },
    {
        "draws": 13,
        "goal_difference": -14,
        "goals_received": 58,
        "goals_scored": 44,
        "losses": 14,
        "played": 38,
        "points": 46,
        "team": "Levante",
        "wins": 11
    },
    {
        "draws": 13,
        "goal_difference": -8,
        "goals_received": 49,
        "goals_scored": 41,
        "losses": 15,
        "played": 38,
        "points": 43,
        "team": "Athletic Bilbao",
        "wins": 10
    },
    {
        "draws": 7,
        "goal_difference": -17,
        "goals_received": 51,
        "goals_scored": 34,
        "losses": 19,
        "played": 38,
        "points": 43,
        "team": "Leganes",
        "wins": 12
    },
    {
        "draws": 11,
        "goal_difference": -38,
        "goals_received": 76,
        "goals_scored": 38,
        "losses": 21,
        "played": 38,
        "points": 29,
        "team": "Deportivo La Coruna",
        "wins": 6
    },
    {
        "draws": 7,
        "goal_difference": -50,
        "goals_received": 74,
        "goals_scored": 24,
        "losses": 26,
        "played": 38,
        "points": 22,
        "team": "Las Palmas",
        "wins": 5
    },
    {
        "draws": 5,
        "goal_difference": -37,
        "goals_received": 61,
        "goals_scored": 24,
        "losses": 28,
        "played": 38,
        "points": 20,
        "team": "Malaga",
        "wins": 5
    }
]

spain2 = [
    {
        "draws": 13,
        "goal_difference": 19,
        "goals_received": 48,
        "goals_scored": 67,
        "losses": 8,
        "played": 42,
        "points": 76,
        "team": "Rayo Vallecano",
        "wins": 21
    },
    {
        "draws": 12,
        "goal_difference": 21,
        "goals_received": 40,
        "goals_scored": 61,
        "losses": 9,
        "played": 42,
        "points": 75,
        "team": "Huesca",
        "wins": 21
    },
    {
        "draws": 11,
        "goal_difference": 13,
        "goals_received": 44,
        "goals_scored": 57,
        "losses": 11,
        "played": 42,
        "points": 71,
        "team": "Real Zaragoza",
        "wins": 20
    },
    {
        "draws": 8,
        "goal_difference": 20,
        "goals_received": 40,
        "goals_scored": 60,
        "losses": 13,
        "played": 42,
        "points": 71,
        "team": "Sporting Gijon",
        "wins": 21
    },
    {
        "draws": 10,
        "goal_difference": 14,
        "goals_received": 55,
        "goals_scored": 69,
        "losses": 13,
        "played": 42,
        "points": 67,
        "team": "Valladolid",
        "wins": 19
    },
    {
        "draws": 11,
        "goal_difference": 11,
        "goals_received": 41,
        "goals_scored": 52,
        "losses": 13,
        "played": 42,
        "points": 65,
        "team": "Numancia",
        "wins": 18
    },
    {
        "draws": 11,
        "goal_difference": 6,
        "goals_received": 48,
        "goals_scored": 54,
        "losses": 13,
        "played": 42,
        "points": 65,
        "team": "Real Oviedo",
        "wins": 18
    },
    {
        "draws": 16,
        "goal_difference": 10,
        "goals_received": 34,
        "goals_scored": 44,
        "losses": 10,
        "played": 42,
        "points": 64,
        "team": "Osasuna",
        "wins": 16
    },
    {
        "draws": 16,
        "goal_difference": 13,
        "goals_received": 29,
        "goals_scored": 42,
        "losses": 10,
        "played": 42,
        "points": 64,
        "team": "Cadiz",
        "wins": 16
    },
    {
        "draws": 10,
        "goal_difference": 5,
        "goals_received": 50,
        "goals_scored": 55,
        "losses": 15,
        "played": 42,
        "points": 61,
        "team": "Granada",
        "wins": 17
    },
    {
        "draws": 14,
        "goal_difference": 8,
        "goals_received": 50,
        "goals_scored": 58,
        "losses": 13,
        "played": 42,
        "points": 59,
        "team": "Tenerife",
        "wins": 15
    },
    {
        "draws": 10,
        "goal_difference": -9,
        "goals_received": 48,
        "goals_scored": 39,
        "losses": 17,
        "played": 42,
        "points": 55,
        "team": "Lugo",
        "wins": 15
    },
    {
        "draws": 16,
        "goal_difference": -5,
        "goals_received": 42,
        "goals_scored": 37,
        "losses": 14,
        "played": 42,
        "points": 52,
        "team": "Alcorcon",
        "wins": 12
    },
    {
        "draws": 16,
        "goal_difference": -11,
        "goals_received": 42,
        "goals_scored": 31,
        "losses": 14,
        "played": 42,
        "points": 52,
        "team": "Reus",
        "wins": 12
    },
    {
        "draws": 7,
        "goal_difference": -6,
        "goals_received": 50,
        "goals_scored": 44,
        "losses": 20,
        "played": 42,
        "points": 52,
        "team": "Gimnastic",
        "wins": 15
    },
    {
        "draws": 6,
        "goal_difference": -8,
        "goals_received": 65,
        "goals_scored": 57,
        "losses": 21,
        "played": 42,
        "points": 51,
        "team": "Cordoba",
        "wins": 15
    },
    {
        "draws": 16,
        "goal_difference": -11,
        "goals_received": 46,
        "goals_scored": 35,
        "losses": 15,
        "played": 42,
        "points": 49,
        "team": "Albacete",
        "wins": 11
    },
    {
        "draws": 12,
        "goal_difference": -7,
        "goals_received": 45,
        "goals_scored": 38,
        "losses": 18,
        "played": 42,
        "points": 48,
        "team": "Almeria",
        "wins": 12
    },
    {
        "draws": 15,
        "goal_difference": -13,
        "goals_received": 67,
        "goals_scored": 54,
        "losses": 16,
        "played": 42,
        "points": 48,
        "team": "Leonesa",
        "wins": 11
    },
    {
        "draws": 14,
        "goal_difference": -8,
        "goals_received": 54,
        "goals_scored": 46,
        "losses": 18,
        "played": 42,
        "points": 44,
        "team": "Barcelona B",
        "wins": 10
    },
    {
        "draws": 9,
        "goal_difference": -31,
        "goals_received": 68,
        "goals_scored": 37,
        "losses": 25,
        "played": 42,
        "points": 33,
        "team": "Lorca FC",
        "wins": 8
    },
    {
        "draws": 11,
        "goal_difference": -31,
        "goals_received": 60,
        "goals_scored": 29,
        "losses": 24,
        "played": 42,
        "points": 32,
        "team": "Sevilla Atletico",
        "wins": 7
    }
]

germany1 = [
    {
        "draws": 3,
        "goal_difference": 64,
        "goals_received": 28,
        "goals_scored": 92,
        "losses": 4,
        "played": 34,
        "points": 84,
        "team": "Bayern Munich",
        "wins": 27
    },
    {
        "draws": 9,
        "goal_difference": 16,
        "goals_received": 37,
        "goals_scored": 53,
        "losses": 7,
        "played": 34,
        "points": 63,
        "team": "Schalke 04",
        "wins": 18
    },
    {
        "draws": 10,
        "goal_difference": 18,
        "goals_received": 48,
        "goals_scored": 66,
        "losses": 9,
        "played": 34,
        "points": 55,
        "team": "Hoffenheim",
        "wins": 15
    },
    {
        "draws": 10,
        "goal_difference": 17,
        "goals_received": 47,
        "goals_scored": 64,
        "losses": 9,
        "played": 34,
        "points": 55,
        "team": "Borussia Dortmund",
        "wins": 15
    },
    {
        "draws": 10,
        "goal_difference": 14,
        "goals_received": 44,
        "goals_scored": 58,
        "losses": 9,
        "played": 34,
        "points": 55,
        "team": "Bayer Leverkusen",
        "wins": 15
    },
    {
        "draws": 8,
        "goal_difference": 4,
        "goals_received": 53,
        "goals_scored": 57,
        "losses": 11,
        "played": 34,
        "points": 53,
        "team": "RasenBallsport Leipzig",
        "wins": 15
    },
    {
        "draws": 6,
        "goal_difference": 0,
        "goals_received": 36,
        "goals_scored": 36,
        "losses": 13,
        "played": 34,
        "points": 51,
        "team": "VfB Stuttgart",
        "wins": 15
    },
    {
        "draws": 7,
        "goal_difference": 0,
        "goals_received": 45,
        "goals_scored": 45,
        "losses": 13,
        "played": 34,
        "points": 49,
        "team": "Eintracht Frankfurt",
        "wins": 14
    },
    {
        "draws": 8,
        "goal_difference": -5,
        "goals_received": 52,
        "goals_scored": 47,
        "losses": 13,
        "played": 34,
        "points": 47,
        "team": "Borussia Moenchengladbach",
        "wins": 13
    },
    {
        "draws": 13,
        "goal_difference": -3,
        "goals_received": 46,
        "goals_scored": 43,
        "losses": 11,
        "played": 34,
        "points": 43,
        "team": "Hertha Berlin",
        "wins": 10
    },
    {
        "draws": 12,
        "goal_difference": -3,
        "goals_received": 40,
        "goals_scored": 37,
        "losses": 12,
        "played": 34,
        "points": 42,
        "team": "Werder Bremen",
        "wins": 10
    },
    {
        "draws": 11,
        "goal_difference": -3,
        "goals_received": 46,
        "goals_scored": 43,
        "losses": 13,
        "played": 34,
        "points": 41,
        "team": "Augsburg",
        "wins": 10
    },
    {
        "draws": 9,
        "goal_difference": -10,
        "goals_received": 54,
        "goals_scored": 44,
        "losses": 15,
        "played": 34,
        "points": 39,
        "team": "Hannover 96",
        "wins": 10
    },
    {
        "draws": 9,
        "goal_difference": -14,
        "goals_received": 52,
        "goals_scored": 38,
        "losses": 16,
        "played": 34,
        "points": 36,
        "team": "Mainz 05",
        "wins": 9
    },
    {
        "draws": 12,
        "goal_difference": -24,
        "goals_received": 56,
        "goals_scored": 32,
        "losses": 14,
        "played": 34,
        "points": 36,
        "team": "Freiburg",
        "wins": 8
    },
    {
        "draws": 15,
        "goal_difference": -12,
        "goals_received": 48,
        "goals_scored": 36,
        "losses": 13,
        "played": 34,
        "points": 33,
        "team": "Wolfsburg",
        "wins": 6
    },
    {
        "draws": 7,
        "goal_difference": -24,
        "goals_received": 53,
        "goals_scored": 29,
        "losses": 19,
        "played": 34,
        "points": 31,
        "team": "Hamburger SV",
        "wins": 8
    },
    {
        "draws": 7,
        "goal_difference": -35,
        "goals_received": 70,
        "goals_scored": 35,
        "losses": 22,
        "played": 34,
        "points": 22,
        "team": "FC Cologne",
        "wins": 5
    }
]

germany2 = [
    {
        "draws": 6,
        "goal_difference": 13,
        "goals_received": 44,
        "goals_scored": 57,
        "losses": 9,
        "played": 34,
        "points": 63,
        "team": "Fortuna Duesseldorf",
        "wins": 19
    },
    {
        "draws": 9,
        "goal_difference": 22,
        "goals_received": 39,
        "goals_scored": 61,
        "losses": 8,
        "played": 34,
        "points": 60,
        "team": "Nuernberg",
        "wins": 17
    },
    {
        "draws": 14,
        "goal_difference": 27,
        "goals_received": 44,
        "goals_scored": 71,
        "losses": 6,
        "played": 34,
        "points": 56,
        "team": "Holstein Kiel",
        "wins": 14
    },
    {
        "draws": 12,
        "goal_difference": 4,
        "goals_received": 47,
        "goals_scored": 51,
        "losses": 10,
        "played": 34,
        "points": 48,
        "team": "Arminia Bielefeld",
        "wins": 12
    },
    {
        "draws": 6,
        "goal_difference": 0,
        "goals_received": 53,
        "goals_scored": 53,
        "losses": 14,
        "played": 34,
        "points": 48,
        "team": "Jahn Regensburg",
        "wins": 14
    },
    {
        "draws": 9,
        "goal_difference": -3,
        "goals_received": 40,
        "goals_scored": 37,
        "losses": 12,
        "played": 34,
        "points": 48,
        "team": "Bochum",
        "wins": 13
    },
    {
        "draws": 9,
        "goal_difference": -4,
        "goals_received": 56,
        "goals_scored": 52,
        "losses": 12,
        "played": 34,
        "points": 48,
        "team": "Duisburg",
        "wins": 13
    },
    {
        "draws": 11,
        "goal_difference": 8,
        "goals_received": 46,
        "goals_scored": 54,
        "losses": 11,
        "played": 34,
        "points": 47,
        "team": "Union Berlin",
        "wins": 12
    },
    {
        "draws": 9,
        "goal_difference": 2,
        "goals_received": 45,
        "goals_scored": 47,
        "losses": 13,
        "played": 34,
        "points": 45,
        "team": "Ingolstadt",
        "wins": 12
    },
    {
        "draws": 13,
        "goal_difference": 2,
        "goals_received": 45,
        "goals_scored": 47,
        "losses": 11,
        "played": 34,
        "points": 43,
        "team": "Darmstadt",
        "wins": 10
    },
    {
        "draws": 10,
        "goal_difference": 2,
        "goals_received": 33,
        "goals_scored": 35,
        "losses": 13,
        "played": 34,
        "points": 43,
        "team": "Sandhausen",
        "wins": 11
    },
    {
        "draws": 10,
        "goal_difference": -13,
        "goals_received": 48,
        "goals_scored": 35,
        "losses": 13,
        "played": 34,
        "points": 43,
        "team": "St. Pauli",
        "wins": 11
    },
    {
        "draws": 9,
        "goal_difference": -6,
        "goals_received": 56,
        "goals_scored": 50,
        "losses": 14,
        "played": 34,
        "points": 42,
        "team": "FC Heidenheim",
        "wins": 11
    },
    {
        "draws": 8,
        "goal_difference": -10,
        "goals_received": 52,
        "goals_scored": 42,
        "losses": 15,
        "played": 34,
        "points": 41,
        "team": "Dynamo Dresden",
        "wins": 11
    },
    {
        "draws": 10,
        "goal_difference": -11,
        "goals_received": 48,
        "goals_scored": 37,
        "losses": 14,
        "played": 34,
        "points": 40,
        "team": "Greuther Fuerth",
        "wins": 10
    },
    {
        "draws": 10,
        "goal_difference": -14,
        "goals_received": 49,
        "goals_scored": 35,
        "losses": 14,
        "played": 34,
        "points": 40,
        "team": "Erzgebirge Aue",
        "wins": 10
    },
    {
        "draws": 15,
        "goal_difference": -6,
        "goals_received": 43,
        "goals_scored": 37,
        "losses": 11,
        "played": 34,
        "points": 39,
        "team": "Eintracht Braunschweig",
        "wins": 8
    },
    {
        "draws": 8,
        "goal_difference": -13,
        "goals_received": 55,
        "goals_scored": 42,
        "losses": 17,
        "played": 34,
        "points": 35,
        "team": "Kaiserslautern",
        "wins": 9
    }
]

france1 = [
    {
        "draws": 6,
        "goal_difference": 79,
        "goals_received": 29,
        "goals_scored": 108,
        "losses": 3,
        "played": 38,
        "points": 93,
        "team": "Paris Saint Germain",
        "wins": 29
    },
    {
        "draws": 8,
        "goal_difference": 40,
        "goals_received": 45,
        "goals_scored": 85,
        "losses": 6,
        "played": 38,
        "points": 80,
        "team": "Monaco",
        "wins": 24
    },
    {
        "draws": 9,
        "goal_difference": 44,
        "goals_received": 43,
        "goals_scored": 87,
        "losses": 6,
        "played": 38,
        "points": 78,
        "team": "Lyon",
        "wins": 23
    },
    {
        "draws": 11,
        "goal_difference": 33,
        "goals_received": 47,
        "goals_scored": 80,
        "losses": 5,
        "played": 38,
        "points": 77,
        "team": "Marseille",
        "wins": 22
    },
    {
        "draws": 10,
        "goal_difference": 6,
        "goals_received": 44,
        "goals_scored": 50,
        "losses": 12,
        "played": 38,
        "points": 58,
        "team": "Rennes",
        "wins": 16
    },
    {
        "draws": 7,
        "goal_difference": 5,
        "goals_received": 48,
        "goals_scored": 53,
        "losses": 15,
        "played": 38,
        "points": 55,
        "team": "Bordeaux",
        "wins": 16
    },
    {
        "draws": 10,
        "goal_difference": -3,
        "goals_received": 50,
        "goals_scored": 47,
        "losses": 13,
        "played": 38,
        "points": 55,
        "team": "Saint-Etienne",
        "wins": 15
    },
    {
        "draws": 9,
        "goal_difference": 1,
        "goals_received": 52,
        "goals_scored": 53,
        "losses": 14,
        "played": 38,
        "points": 54,
        "team": "Nice",
        "wins": 15
    },
    {
        "draws": 10,
        "goal_difference": -5,
        "goals_received": 41,
        "goals_scored": 36,
        "losses": 14,
        "played": 38,
        "points": 52,
        "team": "Nantes",
        "wins": 14
    },
    {
        "draws": 18,
        "goal_difference": 3,
        "goals_received": 33,
        "goals_scored": 36,
        "losses": 9,
        "played": 38,
        "points": 51,
        "team": "Montpellier",
        "wins": 11
    },
    {
        "draws": 9,
        "goal_difference": -18,
        "goals_received": 73,
        "goals_scored": 55,
        "losses": 16,
        "played": 38,
        "points": 48,
        "team": "Dijon",
        "wins": 13
    },
    {
        "draws": 11,
        "goal_difference": -11,
        "goals_received": 59,
        "goals_scored": 48,
        "losses": 15,
        "played": 38,
        "points": 47,
        "team": "Guingamp",
        "wins": 12
    },
    {
        "draws": 9,
        "goal_difference": -5,
        "goals_received": 42,
        "goals_scored": 37,
        "losses": 17,
        "played": 38,
        "points": 45,
        "team": "Amiens",
        "wins": 12
    },
    {
        "draws": 14,
        "goal_difference": -10,
        "goals_received": 52,
        "goals_scored": 42,
        "losses": 15,
        "played": 38,
        "points": 41,
        "team": "Angers",
        "wins": 9
    },
    {
        "draws": 11,
        "goal_difference": -23,
        "goals_received": 67,
        "goals_scored": 44,
        "losses": 18,
        "played": 38,
        "points": 38,
        "team": "Strasbourg",
        "wins": 9
    },
    {
        "draws": 8,
        "goal_difference": -25,
        "goals_received": 52,
        "goals_scored": 27,
        "losses": 20,
        "played": 38,
        "points": 38,
        "team": "Caen",
        "wins": 10
    },
    {
        "draws": 8,
        "goal_difference": -26,
        "goals_received": 67,
        "goals_scored": 41,
        "losses": 20,
        "played": 38,
        "points": 38,
        "team": "Lille",
        "wins": 10
    },
    {
        "draws": 10,
        "goal_difference": -16,
        "goals_received": 54,
        "goals_scored": 38,
        "losses": 19,
        "played": 38,
        "points": 37,
        "team": "Toulouse",
        "wins": 9
    },
    {
        "draws": 6,
        "goal_difference": -27,
        "goals_received": 59,
        "goals_scored": 32,
        "losses": 23,
        "played": 38,
        "points": 33,
        "team": "Troyes",
        "wins": 9
    },
    {
        "draws": 8,
        "goal_difference": -42,
        "goals_received": 76,
        "goals_scored": 34,
        "losses": 24,
        "played": 38,
        "points": 26,
        "team": "Metz",
        "wins": 6
    }
]

france2 = [
    {
        "draws": 4,
        "goal_difference": 50,
        "goals_received": 24,
        "goals_scored": 74,
        "losses": 6,
        "played": 38,
        "points": 88,
        "team": "Reims",
        "wins": 28
    },
    {
        "draws": 7,
        "goal_difference": 38,
        "goals_received": 37,
        "goals_scored": 75,
        "losses": 9,
        "played": 38,
        "points": 73,
        "team": "Nimes",
        "wins": 22
    },
    {
        "draws": 8,
        "goal_difference": 19,
        "goals_received": 43,
        "goals_scored": 62,
        "losses": 10,
        "played": 38,
        "points": 68,
        "team": "AC Ajaccio",
        "wins": 20
    },
    {
        "draws": 9,
        "goal_difference": 19,
        "goals_received": 34,
        "goals_scored": 53,
        "losses": 10,
        "played": 38,
        "points": 66,
        "team": "Le Havre",
        "wins": 19
    },
    {
        "draws": 11,
        "goal_difference": 15,
        "goals_received": 43,
        "goals_scored": 58,
        "losses": 9,
        "played": 38,
        "points": 65,
        "team": "Brest",
        "wins": 18
    },
    {
        "draws": 12,
        "goal_difference": 18,
        "goals_received": 36,
        "goals_scored": 54,
        "losses": 9,
        "played": 38,
        "points": 63,
        "team": "Clermont Foot",
        "wins": 17
    },
    {
        "draws": 8,
        "goal_difference": 15,
        "goals_received": 46,
        "goals_scored": 61,
        "losses": 12,
        "played": 38,
        "points": 62,
        "team": "Lorient",
        "wins": 18
    },
    {
        "draws": 13,
        "goal_difference": 10,
        "goals_received": 36,
        "goals_scored": 46,
        "losses": 9,
        "played": 38,
        "points": 61,
        "team": "Paris FC",
        "wins": 16
    },
    {
        "draws": 9,
        "goal_difference": 0,
        "goals_received": 50,
        "goals_scored": 50,
        "losses": 12,
        "played": 38,
        "points": 60,
        "team": "Chateauroux",
        "wins": 17
    },
    {
        "draws": 8,
        "goal_difference": -11,
        "goals_received": 62,
        "goals_scored": 51,
        "losses": 15,
        "played": 38,
        "points": 53,
        "team": "Sochaux",
        "wins": 15
    },
    {
        "draws": 8,
        "goal_difference": -4,
        "goals_received": 55,
        "goals_scored": 51,
        "losses": 17,
        "played": 38,
        "points": 47,
        "team": "Auxerre",
        "wins": 13
    },
    {
        "draws": 10,
        "goal_difference": -9,
        "goals_received": 61,
        "goals_scored": 52,
        "losses": 16,
        "played": 38,
        "points": 46,
        "team": "Orleans",
        "wins": 12
    },
    {
        "draws": 9,
        "goal_difference": -14,
        "goals_received": 64,
        "goals_scored": 50,
        "losses": 17,
        "played": 38,
        "points": 45,
        "team": "Valenciennes",
        "wins": 12
    },
    {
        "draws": 10,
        "goal_difference": -1,
        "goals_received": 49,
        "goals_scored": 48,
        "losses": 17,
        "played": 38,
        "points": 43,
        "team": "Lens",
        "wins": 11
    },
    {
        "draws": 9,
        "goal_difference": -13,
        "goals_received": 60,
        "goals_scored": 47,
        "losses": 18,
        "played": 38,
        "points": 42,
        "team": "Niort",
        "wins": 11
    },
    {
        "draws": 8,
        "goal_difference": -25,
        "goals_received": 60,
        "goals_scored": 35,
        "losses": 19,
        "played": 38,
        "points": 41,
        "team": "GFC Ajaccio",
        "wins": 11
    },
    {
        "draws": 11,
        "goal_difference": -15,
        "goals_received": 54,
        "goals_scored": 39,
        "losses": 18,
        "played": 38,
        "points": 38,
        "team": "Nancy",
        "wins": 9
    },
    {
        "draws": 6,
        "goal_difference": -37,
        "goals_received": 87,
        "goals_scored": 50,
        "losses": 22,
        "played": 38,
        "points": 36,
        "team": "Bourg en Bresse Peronnas",
        "wins": 10
    },
    {
        "draws": 6,
        "goal_difference": -21,
        "goals_received": 66,
        "goals_scored": 45,
        "losses": 23,
        "played": 38,
        "points": 33,
        "team": "Quevilly",
        "wins": 9
    },
    {
        "draws": 8,
        "goal_difference": -34,
        "goals_received": 68,
        "goals_scored": 34,
        "losses": 25,
        "played": 38,
        "points": 23,
        "team": "Tours",
        "wins": 5
    }
]

expected_data = {
    'http://localhost:5050/england/1': json.dumps(england1).replace(' ', ''),
    'http://localhost:5050/england/2': json.dumps(england2).replace(' ', ''),
    'http://localhost:5050/england/3': json.dumps(england3).replace(' ', ''),
    'http://localhost:5050/england/4': json.dumps(england4).replace(' ', ''),
    'http://localhost:5050/spain/1': json.dumps(spain1).replace(' ', ''),
    'http://localhost:5050/spain/2': json.dumps(spain2).replace(' ', ''),
    'http://localhost:5050/italy/1': json.dumps(italy1).replace(' ', ''),
    'http://localhost:5050/italy/2': json.dumps(italy2).replace(' ', ''),
    'http://localhost:5050/germany/1': json.dumps(germany1).replace(' ', ''),
    'http://localhost:5050/germany/2': json.dumps(germany2).replace(' ', ''),
    'http://localhost:5050/france/1': json.dumps(france1).replace(' ', ''),
    'http://localhost:5050/france/2': json.dumps(france2).replace(' ', '')
}


class RequestThread(threading.Thread):
    def run(self):
        path = random.sample(expected_data.keys(), 1)[0]
        res = request.urlopen(path, timeout=5).read().decode('utf-8').replace(' ', '')
        if not res == expected_data[path]:
            print('mis match !!!!')
            print(res)
            print(expected_data[path])
            sys.exit(1)


if __name__ == '__main__':
    now = time.time()
    future = now + 120
    rnd = 1
    while time.time() < future:
        threads = [RequestThread(name="Thread-%d" % (x+1)) for x in range(1000)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        print('Round %d done' % rnd)
        rnd += 1
